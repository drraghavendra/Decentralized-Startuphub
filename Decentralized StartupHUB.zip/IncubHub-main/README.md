frontend and react part of the code is present inside the root folder
```
cd frontend
```
enter the frontend folder
```
npm i
```
after all files get installed use 
``` npm run dev```
